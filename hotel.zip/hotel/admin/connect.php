<?php
	$conn = new mysqli("localhost", "root", "", "db_hor") or die(mysqli_error($conn));
	// $conn = new mysqli("localhost:3307", "root", "", "client-hotel-booking") or die(mysqli_error($conn));